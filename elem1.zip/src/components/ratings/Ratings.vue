<template>
  <div class="ratings" ref="ratings">
    <div class="ratings-content">
      <div class="overview">
        <div class="overview-left">
          <h1 class="score">{{Hseller.score}}</h1>
          <div class="title">综合评分</div>
          <div class="rank">高于周边商家{{Hseller.rankRate}}%</div>
        </div>
        <div class="overview-right">
          <div class="score-wrapper">
            <span class="title">服务态度</span>
            <Star :size="36" :score="Hseller.serviceScore"></Star>
            <span class="score">{{Hseller.serviceScore}}</span>
          </div>
          <div class="score-wrapper">
            <span class="title">商品评分</span>
            <Star :size="36" :score="Hseller.foodScore"></Star>
            <span class="score">{{Hseller.foodScore}}</span>
          </div>
          <div class="delivery-wrapper">
            <span class="title">送达时间</span>
            <span class="delivery">{{Hseller.deliveryTime}}分钟</span>
          </div>
        </div>
      </div>
      <Split></Split>
      <Ratingselect @content-toggle="contentToggle" @Ratingtype-select="RatingtypeSelect" :select-type="selectType" :only-content="onlyContent" :ratings="ratings"></Ratingselect>
      <div class="rating-wrapper">
        <ul>
          <li v-show="needShow(rating.rateType, rating.text)" v-for="(rating, key) in ratings" :key="key" class="rating-item">
            <div claass="avatar">
              <img width="28" height="28" :src="rating.avatar"/>
            </div>
            <div class="content">
              <h1 class="name">{{rating.username}}</h1>
              <div class="star-wrapper">
                <Star :size="24" :score="rating.score"></Star>
                <span class="delivery" v-show="rating.deliveryTime">
                  {{rating.deliveryTime}}
                </span>
              </div>
              <p class="text">{{rating.text}}</p>
              <div class="recommend" v-show="rating.recommend && rating.recommend.length">
                <i class="fa fa-thumbs-up"></i>
                <span v-for="(item, key) in rating.recommend" :key="key" class="item">{{item}}</span>
              </div>
              <div class="time">
                {{rating.rateTime | formatDate}}
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import BScroll from 'better-scroll'
import Star from '../star/Star'
import Split from '../split/Split'
import Ratingselect from '../ratingselect/Ratingselect'
import {formatDate} from '../../commom/js/date.js'
const errOk = 0
const All = 2
export default {
  data () {
    return {
      ratings: [],
      selectType: All,
      onlyContent: false
    }
  },
  props: {
    Hseller: {
      type: Object
    }
  },
  components: {
    Star,
    Split,
    Ratingselect
  },
  created () {
    this.$http.get('/api/ratings').then(function (res) {
      if (res.data.errno === errOk) {
        res = res.data
        this.ratings = res.data
        this.$nextTick(function () {
          this.scroll = new BScroll(this.$refs.ratings, {
            click: true
          })
        })
      }
    }.bind(this))
  },
  methods: {
    RatingtypeSelect (type) {
      this.selectType = type
      this.$nextTick(function () {
        this.scroll.refresh()
      })
    },
    contentToggle (data) {
      this.onlyContent = data
      this.$nextTick(function () {
        this.scroll.refresh()
      })
    },
    needShow (type, text) {
      if (this.onlyContent && !text) {
        return false
      }
      if (this.selectType === All) {
        return true
      } else {
        return type === this.selectType
      }
    }
  },
  filters: {
    formatDate (time) {
      let date = new Date(time)
      return formatDate(date, 'yyyy-MM-dd hh:mm')
    }
  }
}
</script>

<style lang="stylus" scoped>
@import '../../../static/css/font-awesome.css'
@import '../../commom/stylus/mixin.styl'
.ratings
  position: absolute
  top: 174px
  left: 0
  bottom: 0;
  width: 100%
  overflow: hidden
  .overview
    display: flex
    padding: 18px 0
    .overview-left
      flex: 0 0 137px
      padding: 6px 0
      width: 137px
      border-right: 1px solid rgba(7, 17, 27, .1)
      text-align: center
      @media only screen and (max-width: 320px)
        flex: 0 0 120px
        width: 120px
      .score
        margin-bottom: 6px
        line-height: 28px
        font-size: 24px
        color: rgb(255, 153, 0)
      .title
        margin-bottom: 8px
        line-height: 12px
        font-size: 12px
        color: rgb(7, 17, 27)
      .rank
        line-height: 10px
        font-size: 10px
        color: rgb(147, 153, 159)
    .overview-right
      flex: 1
      padding: 6px 0 6px 24px
      @media only screen and (max-width: 320px)
        padding-left: 6px
      .score-wrapper
        margin-bottom: 8px
        font-size: 0
        .title
          display: inline-block
          font-size: 12px
          line-height: 18px
          color: rgb(7, 17, 27)
        .star
          display: inline-block
          margin: 0 12px
          vertical-align: top
        .score
          display: inline-block
          line-height: 18px
          vertical-align: top
          font-size: 12px
          color: rgb(255, 153, 0)
      .delivery-wrapper
        font-size: 12px
        .title
          line-height: 18px
          color: rgb(7, 17, 27)
        .delivery
          margin-left: 12px
          color: rgb(147, 153, 159)
  .rating-wrapper
    padding: 0 18px
    .rating-item
      display: flex
      padding: 18px 0
      border-1px(rgba(7, 17, 27, .1))
      .avatar
        flex: 0 0 28px
        width: 28px
        margin-right: 12px
        img
          border-radius: 50%
      .content
        position: relative
        flex: 1
        .name
          margin-bottom: 4px
          line-height: 12px
          font-size: 10px
          color: rgb(7, 17, 27)
        .star-wrapper
          margin-bottom: 6px
          font-size: 0
          .star
            display: inline-block
            margin-right: 6px
            vertical-align: top
          .delivery
            display: inline-block
            vertical-align: top
            line-height: 12px
            font-size: 10px
            color: rgb(147, 153, 159)
        .text
          margin-bottom: 8px
          line-height: 18px
          color: rgb(7, 17, 27)
          font-size: 12px
        .recommend
          line-height: 16px
          font-size: 0
          .fa-thumbs-up,.item
            display: inline-block
            margin: 0 8px 4px 0
            font-size: 9px
          .fa-thumbs-up
            color: rgb(0, 160, 220)
          .item
            padding: 0 6px
            border: 1px solid rgba(7, 17, 27, .1)
            color: rgb(147, 153, 159)
            background: #fff
        .time
          position: absolute
          top: 0
          right: 0
          line-height: 12px
          font-size: 10px
          color: rgb(147, 153, 159)
</style>
